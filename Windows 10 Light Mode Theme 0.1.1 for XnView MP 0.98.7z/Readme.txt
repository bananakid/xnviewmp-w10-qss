
Windows 10 Light Mode Qt 5.15.1 Style Sheet for XnView MP 0.98

Version 0.1.1

Release 10.01.2021


Quick essential fixes to default Qt Style Sheet for Windows 10


Installation


1. To get complete UI look as in previews:

1) copy files folder "Qt 5 Style Sheet & Settings"
   to folder %UserProfile%\AppData\Roaming\XnViewMP

2) copy folder "svg" from folder "UI Images"
   to folder "C:\Program Files\XnView MP\UI"


2. To get just theme and keeping your UI settings:

1) copy files "style_sheet.qss" and "style_sheet_win.qss"
   from folder "Qt 5 Style Sheet & Settings"
   to folder %UserProfile%\AppData\Roaming\XnViewMP

2) copy folder "svg" from folder "UI Images"
   to folder "C:\Program Files\XnView MP\UI"

3) launch XnView MP 0.96 and select theme using menu
   "View > Theme > Dark theme", then close and reopen XnView MP
